Implementations of states defined in `refcpu/context.svh`. By design, they are expected to be only combinatorial logic circuits.

`Unknown.sv` is an example implementation.
