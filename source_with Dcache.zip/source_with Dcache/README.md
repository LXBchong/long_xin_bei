See `refcpu/add_sources.tcl` for writing your own TCL scripting.
